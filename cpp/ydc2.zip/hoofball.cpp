#include<bits/stdc++.h>
using namespace std;
const int f=100;
const bool up=true,down=false;
int n,cnt,cur,cg=2,cnt2,previ;
struct cow{
	int dis;
}co[f+2];
struct cmp{
	bool operator()(cow &a,cow &b){
		return a.dis>b.dis;
	}
};
priority_queue<cow,vector<cow>,cmp>d; 
int main(){
	freopen("hoofball.in","r",stdin);
	freopen("hoofball.out","w",stdout);
	cin>>n;
	int temp;
	for(int i=0;i<n;i++){
		cin>>temp;
		d.push({temp});
	}
	cow lt;
	for(int i=0;i<n;i++){
		co[i+1].dis=d.top().dis;
		d.pop();
	}
	bool mode=up;
	previ=co[1].dis;
	cur=co[2].dis;
	while(cg<n){
		cg++;
		if(co[cg].dis+previ>2*cur){
			if(mode==down){
				mode=up;
			}
		}
		else if(co[cg].dis+previ<2*cur){
			if(mode==up){
				mode=down;
				cnt++;cnt++; 
			}
		}
		previ=cur;
		cur=co[cg].dis;
	}
	cg=2;
	mode=up;
	previ=co[1].dis;
	cur=co[2].dis;
	while(cg<n){
		cg++;
		if(co[cg].dis+previ>2*cur){
			if(mode==down){
				mode=up;
			}
		}
		else if(co[cg].dis+previ<2*cur){
			if(mode==up){
				mode=down;
				cnt2++;cnt2++;
			}
		}
		previ=cur;
		cur=co[cg].dis;
	}
	cout<<min(cnt,cnt2);
	return 0;
}
